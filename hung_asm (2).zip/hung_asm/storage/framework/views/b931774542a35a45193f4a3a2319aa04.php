<?php if(session('success')): ?>
<div class="alert alert-success">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(session('error')): ?>
<div class="alert alert-danger">
    <?php echo e(session('error')); ?>

</div>
<?php endif; ?>

<?php $__env->startSection('title', "them danh muc"); ?>;

<?php $__env->startSection('content'); ?>
<div class="card">
    <h2>them danh muc</h2>
    <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary">them danh muc</a>
    <div class="card-body">
        <form action="<?php echo e(route('categories.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label class="form-label">ten danh muc</label>
                <input type="text" name="name" class="form-control">
            </div>
            <div class="mb-3">
                <label class="form-label">mo ta</label>
                <textarea name="description" class="form-control" rows="3"></textarea>
            </div>
            <button type="submit" class="btn btn-success">them moi</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PC\Downloads\htdocs\ASM---PHP3\hehehe\resources\views/admin/categories/add.blade.php ENDPATH**/ ?>
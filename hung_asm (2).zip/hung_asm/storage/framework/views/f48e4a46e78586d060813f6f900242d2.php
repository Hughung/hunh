<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng ký tài khoản (Phiên bản 7 Màu)</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <style>
        /* Hiệu ứng 7 màu cho chữ */
        @keyframes nhayMauChu {
            0% { color: red; }
            14% { color: orange; }
            28% { color: yellow; }
            42% { color: green; }
            57% { color: blue; }
            71% { color: indigo; }
            85% { color: violet; }
            100% { color: red; }
        }

        /* Hiệu ứng 7 màu cho nền */
        @keyframes nhayMauNen {
            0% { background-color: red; border-color: red; }
            14% { background-color: orange; border-color: orange; }
            28% { background-color: yellow; border-color: yellow; }
            42% { background-color: green; border-color: green; }
            57% { background-color: blue; border-color: blue; }
            71% { background-color: indigo; border-color: indigo; }
            85% { background-color: violet; border-color: violet; }
            100% { background-color: red; border-color: red; }
        }

        /* Class áp dụng đổi màu chữ (1.5s) */
        .chu-7-mau {
            animation: nhayMauChu 1.5s infinite !important;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
        }

        /* Class áp dụng đổi màu nền và hiệu ứng xoay */
        .nut-7-mau {
            animation: nhayMauNen 1.5s infinite !important;
            transition: transform 0.6s ease-in-out;
        }

        /* Khi di chuột vào nút sẽ xoay 360 độ */
        .nut-7-mau:hover {
            transform: rotate(360deg);
        }

        /* Trạng thái ban đầu của link quay lại */
        .link-chay {
            display: inline-block;
            transition: transform 0.4s ease-out;
        }

        /* Class được kích hoạt khi chạm chuột để cố định vị trí mới */
        .da-chay-sang-phai {
            transform: translateX(120px);
        }
    </style>
</head>
<body class="bg-light d-flex align-items-center overflow-hidden" style="min-height: 100vh;">

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-5">
                <div class="card shadow-lg border-0 rounded-4">
                    <div class="card-header bg-dark text-center py-3 rounded-top-4">
                        <h4 class="mb-0 fw-bold chu-7-mau">Đăng ký tài khoản</h4>
                    </div>
                    <div class="card-body p-4 p-sm-5">
                        
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger rounded-3">
                                <ul class="mb-0">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <form action="<?php echo e(route('register')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="name" class="form-label fw-bold chu-7-mau">Họ và Tên</label>
                                <input type="text" class="form-control form-control-lg bg-light" id="name" name="name" value="<?php echo e(old('name')); ?>" placeholder="Nhập họ và tên..." required>
                            </div>

                            <div class="mb-3">
                                <label for="email" class="form-label fw-bold chu-7-mau">Email</label>
                                <input type="email" class="form-control form-control-lg bg-light" id="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="Nhập địa chỉ email..." required>
                            </div>

                            <div class="mb-4">
                                <label for="password" class="form-label fw-bold chu-7-mau">Mật khẩu</label>
                                <input type="password" class="form-control form-control-lg bg-light" id="password" name="password" placeholder="Nhập mật khẩu..." required>
                            </div>

                            <button type="submit" class="btn btn-lg w-100 mb-3 fw-bold nut-7-mau chu-7-mau rounded-3">Đăng Ký Ngay</button>
                            
                            <div class="text-center mt-4">
                                <p class="text-muted mb-2">
                                    Đã có tài khoản? <a href="<?php echo e(route('login')); ?>" class="text-primary text-decoration-none fw-bold">Đăng nhập</a>
                                </p>
                                
                                <a href="<?php echo e(route('client.product.index')); ?>" 
                                   class="text-decoration-none text-secondary fw-bold link-chay mt-2"
                                   onmouseenter="this.classList.add('da-chay-sang-phai')">
                                    ← Quay lại Trang chủ
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
</html><?php /**PATH C:\Users\PC\Downloads\htdocs\ASM---PHP3\hehehe\resources\views/auth/register.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trang chủ - Danh sách sản phẩm</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('client.product.index')); ?>">Cửa Hàng Của Tôi</a>
            
            <form class="d-flex mx-auto w-50" action="<?php echo e(route('client.product.index')); ?>" method="GET">
                <input class="form-control me-2" type="search" name="search" placeholder="Nhập tên sản phẩm cần tìm..." value="<?php echo e(request('search')); ?>">
                <button class="btn btn-outline-light" type="submit">Tìm</button>
            </form>

            <div class="d-flex align-items-center">
                <?php if(auth()->guard()->guest()): ?>
                    <a href="<?php echo e(route('login')); ?>" class="btn btn-primary me-2">Đăng nhập</a>
                    <a href="/register" class="btn btn-outline-light">Đăng ký</a> <?php endif; ?>

                <?php if(auth()->guard()->check()): ?>
                    <span class="text-white me-3">Xin chào, <?php echo e(Auth::user()->name); ?></span>
                    <form action="<?php echo e(route('logout')); ?>" method="POST" style="margin: 0;">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger">Đăng xuất</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </nav>
    <div class="container">
        <h2 class="mb-4">Sản phẩm mới nhất</h2>
        
        <div class="row">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 mb-4">
                    <div class="card h-100 shadow-sm">
                        <img src="<?php echo e(asset('storage/images/products/' . $product->image)); ?>" 
                             class="card-img-top" 
                             alt="<?php echo e($product->name); ?>" 
                             style="height: 250px; object-fit: cover;"
                             onerror="this.src='https://via.placeholder.com/250x250?text=No+Image'">
                        
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title"><?php echo e($product->name); ?></h5>
                            
                            <p class="text-muted small mb-1">
                                Danh mục: <strong><?php echo e($product->category->name ?? 'Chưa phân loại'); ?></strong>
                            </p>
                            
                            <h6 class="card-subtitle mb-3 text-danger fw-bold">
                                Giá: <?php echo e(number_format($product->price, 0, ',', '.')); ?> VNĐ
                            </h6>
                            
                            <div class="mt-auto">
                                <a href="<?php echo e(route('client.product.detail', $product->id)); ?>" class="btn btn-outline-primary w-100">Xem chi tiết</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <?php if($products->isEmpty()): ?>
            <div class="alert alert-warning text-center">
                Không tìm thấy sản phẩm nào khớp với từ khóa "<?php echo e(request('search')); ?>"
            </div>
        <?php endif; ?>
    </div>

</body>
</html><?php /**PATH C:\xampp\htdocs\ASM---PHP3\quan\resources\views/client/list.blade.php ENDPATH**/ ?>
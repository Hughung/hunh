<?php $__env->startSection('title', "Quản Lý Danh Mục"); ?>

<?php $__env->startSection('content'); ?>
<style>
    .search-box { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 1.5rem; border-radius: 12px; margin-bottom: 2rem; }
    .btn-add { background: linear-gradient(135deg, #00d084 0%, #00a86b 100%); border: none; color: white; border-radius: 8px; }
</style>

<?php if(session('success')): ?>
    <div class="alert alert-success">✅ <?php echo e(session('success')); ?></div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger">❌ <?php echo e(session('error')); ?></div>
<?php endif; ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h2 style="color: #667eea; font-weight: 700;">📂 Quản Lý Danh Mục</h2>
    <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-add">+ Thêm Danh Mục</a>
</div>

<div class="search-box">
    <form action="<?php echo e(route('categories.index')); ?>" method="GET" class="d-flex gap-2">
        <input type="text" name="search" class="form-control" placeholder="🔍 Tìm danh mục..." value="<?php echo e(request('search')); ?>">
        <button type="submit" class="btn btn-light fw-bold">Tìm Kiếm</button>
    </form>
</div>

<div class="table-responsive">
    <table class="table table-hover align-middle">
        <thead>
            <tr>
                <th style="color: white;">ID</th>
                <th style="color: white;">Tên</th>
                <th style="color: white;">Mô tả</th>
                <th style="color: white;">Hành Động</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><strong>#<?php echo e($category->id); ?></strong></td>
                <td><strong><?php echo e($category->name); ?></strong></td>
                <td><?php echo e(Str::limit($category->description, 50)); ?></td>
                <td>
                    <a href="<?php echo e(route('categories.edit', $category->id)); ?>" class="btn btn-warning btn-sm">✏️ Sửa</a>
                    <form action="<?php echo e(route('categories.destroy', $category->id)); ?>" class="d-inline" method="POST">
                        <?php echo csrf_field(); ?> <?php echo method_field("DELETE"); ?>
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Bạn chắc chắn muốn xóa?')">🗑️ Xóa</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="4" class="text-center text-muted py-4">Không có danh mục nào</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hung_asm\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>
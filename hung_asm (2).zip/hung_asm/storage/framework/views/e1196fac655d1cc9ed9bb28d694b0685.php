<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cửa Hàng - Danh Sách Sản Phẩm</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        /* Header navigation */
        .client-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 1.2rem 0;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            margin-bottom: 2rem;
        }

        .navbar-brand img {
            border-radius: 15px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        }

        .navbar-brand img:hover {
            transform: scale(1.08);
            box-shadow: 0 8px 20px rgba(102, 126, 234, 0.4);
        }

        /* Search box */
        .search-container {
            background: rgba(255, 255, 255, 0.1);
            padding: 1rem;
            border-radius: 30px;
            backdrop-filter: blur(10px);
            border: 2px solid rgba(255, 255, 255, 0.2);
        }

        .search-container input {
            background: white;
            border: none;
            border-radius: 25px;
            padding: 0.7rem 1.2rem;
            width: 100%;
            transition: all 0.3s ease;
        }

        .search-container input:focus {
            outline: none;
            box-shadow: 0 0 15px rgba(102, 126, 234, 0.3);
        }

        .search-container button {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            border: none;
            color: white;
            border-radius: 25px;
            padding: 0.7rem 1.8rem;
            font-weight: 700;
            transition: all 0.3s ease;
            margin-left: 0.5rem;
        }

        .search-container button:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(245, 87, 108, 0.3);
        }

        /* Auth buttons */
        .auth-buttons {
            display: flex;
            gap: 0.8rem;
            flex-wrap: wrap;
        }

        .btn-auth {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            border: 2px solid rgba(255, 255, 255, 0.3);
            border-radius: 25px;
            padding: 0.6rem 1.3rem;
            font-weight: 700;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .btn-auth:hover {
            background: rgba(255, 255, 255, 0.3);
            border-color: rgba(255, 255, 255, 0.6);
            color: white;
            transform: translateY(-2px);
        }

        .btn-logout {
            background: linear-gradient(135deg, #f5576c 0%, #f093fb 100%);
            color: white;
            border: none;
            border-radius: 25px;
            padding: 0.6rem 1.3rem;
            font-weight: 700;
            transition: all 0.3s ease;
        }

        .btn-logout:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(245, 87, 108, 0.3);
        }

        /* Product cards */
        .product-card {
            background: white;
            border: none;
            border-radius: 18px;
            overflow: hidden;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
            height: 100%;
        }

        .product-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 12px 30px rgba(102, 126, 234, 0.25);
        }

        .product-image {
            height: 280px;
            overflow: hidden;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }

        .product-image img {
            max-height: 100%;
            max-width: 100%;
            object-fit: contain;
            transition: all 0.3s ease;
        }

        .product-card:hover .product-image img {
            transform: scale(1.08);
        }

        .product-body {
            padding: 1.5rem;
            display: flex;
            flex-direction: column;
            gap: 0.8rem;
            text-align: center;
        }

        .product-title {
            font-size: 1.1rem;
            font-weight: 700;
            color: #333;
            margin: 0;
        }

        .product-category {
            font-size: 0.9rem;
            color: #999;
            margin: 0;
        }

        .product-category strong {
            color: #667eea;
        }

        .product-price {
            font-size: 1.4rem;
            font-weight: 700;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin: 0.5rem 0;
        }

        .product-button {
            background: linear-gradient(135deg, #00d084 0%, #00a86b 100%);
            color: white;
            border: none;
            border-radius: 12px;
            padding: 0.8rem 1.2rem;
            font-weight: 700;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
            margin-top: 0.5rem;
        }

        .product-button:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 18px rgba(0, 208, 132, 0.3);
            color: white;
        }

        /* Empty state */
        .empty-state {
            background: white;
            border-radius: 15px;
            padding: 3rem 2rem;
            text-align: center;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
            margin: 2rem 0;
        }

        .empty-state h3 {
            font-size: 1.5rem;
            color: #667eea;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }

        .empty-state p {
            color: #999;
            font-size: 1.1rem;
        }

        /* Container */
        .products-container {
            padding: 2rem 0;
        }
    </style>
</head>
<body>

    <!-- Header/Navigation -->
    <div class="client-header">
        <div class="container">
            <div class="row align-items-center gy-3">
                <!-- Logo -->
                <div class="col-lg-2 col-md-3 col-6 text-center text-lg-start">
                    <a href="<?php echo e(route('client.product.index')); ?>" class="text-decoration-none">
                        <img src="<?php echo e(asset('storage/images/hip.png')); ?>" alt="Logo" height="80px">
                    </a>
                </div>

                <!-- Search -->
                <div class="col-lg-5 col-md-6">
                    <form action="<?php echo e(route('client.product.index')); ?>" method="GET" class="search-container d-flex">
                        <input type="search" name="search" placeholder="🔍 Tìm sản phẩm..." value="<?php echo e(request('search')); ?>" class="flex-grow-1">
                        <button type="submit" class="ms-2">Tìm</button>
                    </form>
                </div>

                <!-- Auth Buttons -->
                <div class="col-lg-5 col-md-12">
                    <div class="auth-buttons justify-content-end d-flex">
                        <?php if(auth()->guard()->guest()): ?>
                            <a href="<?php echo e(route('login')); ?>" class="btn-auth">📝 Đăng Nhập</a>
                            <a href="/register" class="btn-auth">✍️ Đăng Ký</a>
                        <?php endif; ?>
                        <?php if(auth()->guard()->check()): ?>
                            <form action="<?php echo e(route('logout')); ?>" method="POST" style="margin: 0;">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn-logout">🚪 Đăng Xuất</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Products Section -->
    <div class="container products-container">
        <div class="row g-4">
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-lg-3 col-md-4 col-sm-6">
                    <div class="product-card">
                        <div class="product-image">
                            <?php if($product->image): ?>
                                <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>">
                            <?php else: ?>
                                <span style="font-size: 3rem; color: #ccc;">📷</span>
                            <?php endif; ?>
                        </div>
                        <div class="product-body">
                            <h5 class="product-title"><?php echo e($product->name); ?></h5>
                            <p class="product-category">
                                📂 <?php echo e($product->category->name ?? 'Không xác định'); ?>

                            </p>
                            <div class="product-price"><?php echo e(number_format($product->price)); ?>đ</div>
                            <a href="<?php echo e(route('client.product.detail', $product->id)); ?>" class="product-button">👁️ Xem Chi Tiết</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12">
                    <div class="empty-state">
                        <h3>❌ Không Tìm Thấy Sản Phẩm</h3>
                        <p>Không có sản phẩm phù hợp với từ khóa "<strong><?php echo e(request('search')); ?></strong>"</p>
                        <a href="<?php echo e(route('client.product.index')); ?>" class="product-button mt-3">🔄 Quay Lại</a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

</body>
</html><?php /**PATH C:\xampp\htdocs\hung_asm\resources\views/client/list.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trang chủ - Danh sách sản phẩm</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <style>
        /* === HIỆU ỨNG CHO HEADER === */
        /* Nền 7 màu */
        @keyframes nhayMauNen {
            0% { background-color: red; border-color: red; } 
            14% { background-color: orange; border-color: orange; } 
            28% { background-color: yellow; border-color: yellow; }
            42% { background-color: green; border-color: green; } 
            57% { background-color: blue; border-color: blue; } 
            71% { background-color: indigo; border-color: indigo; }
            85% { background-color: violet; border-color: violet; } 
            100% { background-color: red; border-color: red; }
        }
        .nen-7-mau {
            animation: nhayMauNen 1.5s infinite !important;
            color: white !important;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.5);
        }

        /* Lắc lư khi hover */
        @keyframes lacLu {
            0% { transform: rotate(0deg); }
            25% { transform: rotate(-15deg) scale(1.1); }
            50% { transform: rotate(15deg) scale(1.1); }
            75% { transform: rotate(-15deg) scale(1.1); }
            100% { transform: rotate(0deg) scale(1); }
        }
        .nut-lac-lu:hover {
            animation: lacLu 0.3s infinite;
            z-index: 10;
        }

        /* Viền ô tìm kiếm 7 màu */
        @keyframes vien7Mau {
            0% { box-shadow: 0 0 10px red; border-color: red; }
            33% { box-shadow: 0 0 10px green; border-color: green; }
            66% { box-shadow: 0 0 10px blue; border-color: blue; }
            100% { box-shadow: 0 0 10px red; border-color: red; }
        }
        .input-troll:focus {
            animation: vien7Mau 1s infinite !important;
            outline: none;
        }

        /* Logo đập nhịp */
        @keyframes nhipDapLogo {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }
        .logo-giat-giat {
            animation: nhipDapLogo 0.5s infinite;
        }


        /* === HIỆU ỨNG CHO SẢN PHẨM (GIỮ NGUYÊN NHƯ CŨ) === */
        @keyframes nhayMauChu {
            0% { color: red; } 14% { color: orange; } 28% { color: yellow; } 
            42% { color: green; } 57% { color: blue; } 71% { color: indigo; } 
            85% { color: violet; } 100% { color: red; }
        }
        .chu-7-mau { animation: nhayMauChu 0.5s infinite !important; }

        @keyframes rungLac {
            0% { transform: translate(1px, 1px) rotate(0deg); }
            20% { transform: translate(-3px, 0px) rotate(1deg); }
            40% { transform: translate(1px, -1px) rotate(1deg); }
            60% { transform: translate(-3px, 1px) rotate(0deg); }
            80% { transform: translate(-1px, -1px) rotate(1deg); }
            100% { transform: translate(1px, -2px) rotate(-1deg); }
        }
        .card-troll { transition: all 0.3s; }
        .card-troll:hover {
            animation: rungLac 0.1s infinite;
            box-shadow: 0 0 20px red, 0 0 40px yellow !important;
            z-index: 10;
        }

        @keyframes nhipDapAnh {
            0% { transform: scale(1); }
            50% { transform: scale(1.1) rotate(3deg); }
            100% { transform: scale(1); }
        }
        .anh-nhap-nhom { animation: nhipDapAnh 1s infinite; }

        .nut-chong-mat { transition: transform 0.5s cubic-bezier(0.68, -0.55, 0.27, 1.55); }
        .nut-chong-mat:hover {
            transform: rotate(720deg) scale(0.8);
            background-color: #ff00ff !important;
            color: white !important;
            border-color: #ff00ff !important;
        }
    </style>
</head>
<body class="bg-light">

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4 shadow-lg" style="border-bottom: 3px solid red; animation: vien7Mau 2s infinite;">
        <div class="container">
            <a class="navbar-brand logo-giat-giat" href="<?php echo e(route('client.product.index')); ?>">
                <img src="<?php echo e(asset('images/image.png')); ?>" alt="Logo" width="150px">
            </a>
            
            <form class="d-flex mx-auto w-50" action="<?php echo e(route('client.product.index')); ?>" method="GET">
                <input class="form-control me-2 input-troll fw-bold" type="search" name="search" placeholder="Nhập tên sản phẩm cần tìm..." value="<?php echo e(request('search')); ?>">
                <button class="btn fw-bold nen-7-mau nut-lac-lu" type="submit" style="border:none;">Tìm</button>
            </form>

            <div class="d-flex align-items-center gap-2">
                <?php if(auth()->guard()->guest()): ?>
                    <a href="<?php echo e(route('login')); ?>" class="btn fw-bold nen-7-mau nut-lac-lu">Đăng nhập</a>
                    <a href="/register" class="btn fw-bold text-dark nut-lac-lu" style="background-color: #fff;">Đăng ký</a> 
                <?php endif; ?>
                <?php if(auth()->guard()->check()): ?>
                    <form action="<?php echo e(route('logout')); ?>" method="POST" style="margin: 0;">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger fw-bold nut-lac-lu">Đăng xuất</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <marquee behavior="" direction="" scrollamount="30">
        <strong style="font-size: 50px; color: #ff4500;">Khô Sát Sườn, Khô Xé Sợi, Khô Đét Đèn Đẹt, Lãnh Chúa Xương, Bộ Trưởng Bộ Hài Cốt</strong>
    </marquee>
    
    <div class="container mt-4">        
        <div class="row">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 mb-4">
                    <div class="card h-100 shadow-sm card-troll border-0 rounded-4 overflow-hidden bg-white">
                        
                        <div class="overflow-hidden bg-light" style="height: 200px; display: flex; align-items: center; justify-content: center;">
                            <?php if($product->image): ?>
                                <img src="<?php echo e(asset('storage/' . $product->image)); ?>" class="img-fluid anh-nhap-nhom" alt="<?php echo e($product->name); ?>" style="max-height: 100%; object-fit: contain;">
                            <?php else: ?>
                                <img src="https://via.placeholder.com/150" class="img-fluid anh-nhap-nhom" alt="Chưa có ảnh">
                            <?php endif; ?>
                        </div>
                        
                        <div class="card-body d-flex flex-column text-center">
                            <h5 class="card-title fw-bold"><?php echo e($product->name); ?></h5>
                            
                            <p class="text-muted small mb-1">
                                Danh mục: <strong><?php echo e($product->category->name ?? 'Chưa phân loại'); ?></strong>
                            </p>
                            
                            <h6 class="card-subtitle mb-3 fw-bold chu-7-mau" style="font-size: 1.2rem;">
                                Giá: <?php echo e(number_format($product->price, 0, ',', '.')); ?> VNĐ
                            </h6>
                            
                            <div class="mt-auto">
                                <a href="<?php echo e(route('client.product.detail', $product->id)); ?>" class="btn btn-outline-primary w-100 fw-bold nut-chong-mat">Xem chi tiết</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <?php if($products->isEmpty()): ?>
            <div class="alert alert-warning text-center fw-bold fs-5">
                Không tìm thấy Hài Cốt nào khớp với từ khóa "<?php echo e(request('search')); ?>"
            </div>
        <?php endif; ?>
    </div>

</body>
</html><?php /**PATH C:\Users\PC\Downloads\htdocs\ASM---PHP3\hehehe\resources\views/client/list.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title', "Quản lý sản phẩm"); ?>
<?php $__env->startSection('content'); ?>
<style>
    .search-box { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 1.5rem; border-radius: 12px; margin-bottom: 2rem; }
    .search-box input { border-radius: 8px; border: 2px solid #e0e0e0; }
    .btn-add { background: linear-gradient(135deg, #00d084 0%, #00a86b 100%); border: none; color: white; border-radius: 8px; }
</style>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h2 style="color: #667eea; font-weight: 700;">📦 Quản Lý Sản Phẩm</h2>
    <a href="<?php echo e(route('products.create')); ?>" class="btn btn-add">+ Thêm Sản Phẩm</a>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success">✅ <?php echo e(session('success')); ?></div>
<?php endif; ?>

<div class="search-box">
    <form action="<?php echo e(route('products.index')); ?>" method="GET" class="d-flex gap-2">
        <input type="text" name="search" class="form-control" placeholder="🔍 Tìm sản phẩm..." value="<?php echo e(request('search')); ?>">
        <button type="submit" class="btn btn-light fw-bold">Tìm Kiếm</button>
    </form>
</div>

<div class="table-responsive">
    <table class="table table-hover align-middle">
        <thead>
            <tr>
                <th style="color: white;">ID</th>
                <th style="color: white;">Ảnh</th>
                <th style="color: white;">Tên SP</th>
                <th style="color: white;">Giá</th>
                <th style="color: white;">Số lượng</th>
                <th style="color: white;">Danh mục</th>
                <th style="color: white;">Hành động</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><strong>#<?php echo e($pro->id); ?></strong></td>
                <td><?php if($pro->image): ?><img src="<?php echo e(asset('storage/' . $pro->image)); ?>" width="70" height="70" style="border-radius: 10px;" alt="<?php echo e($pro->name); ?>"><?php else: ?><span class="text-muted">-</span><?php endif; ?></td>
                <td><strong><?php echo e($pro->name); ?></strong></td>
                <td class="text-danger fw-bold"><?php echo e(number_format($pro->price)); ?>đ</td>
                <td><span class="badge bg-info"><?php echo e($pro->quantity); ?></span></td>
                <td><?php echo e($pro->category->name ?? 'N/A'); ?></td>
                <td>
                    <a href="<?php echo e(route('products.edit', $pro->id)); ?>" class="btn btn-warning btn-sm">✏️ Sửa</a>
                    <form action="<?php echo e(route('products.destroy', $pro->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?> <?php echo method_field("DELETE"); ?>
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Bạn chắc chắn muốn xóa?')">🗑️ Xóa</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="7" class="text-center text-muted py-4">Không có sản phẩm nào</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hung_asm\resources\views/admin/products/index.blade.php ENDPATH**/ ?>
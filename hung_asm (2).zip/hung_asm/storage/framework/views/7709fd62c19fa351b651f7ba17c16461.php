<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Đăng nhập (Phiên bản 7 Màu)</title>

    <style>
        /* Hiệu ứng nhấp nháy 7 màu cho chữ */
        @keyframes nhayMauChu {
            0% { color: red; }
            14% { color: orange; }
            28% { color: yellow; }
            42% { color: green; }
            57% { color: blue; }
            71% { color: indigo; }
            85% { color: violet; }
            100% { color: red; }
        }

        /* Hiệu ứng nhấp nháy 7 màu cho nền */
        @keyframes nhayMauNen {
            0% { background-color: red; border-color: red; }
            14% { background-color: orange; border-color: orange; }
            28% { background-color: yellow; border-color: yellow; }
            42% { background-color: green; border-color: green; }
            57% { background-color: blue; border-color: blue; }
            71% { background-color: indigo; border-color: indigo; }
            85% { background-color: violet; border-color: violet; }
            100% { background-color: red; border-color: red; }
        }

        /* Class áp dụng nháy chữ (0.2s để nháy cực nhanh) */
        .chu-7-mau {
            animation: nhayMauChu 1.5s infinite !important;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.5); /* Đổ bóng xíu để lỡ màu chói quá vẫn đọc được */
        }

        /* Class áp dụng nháy nền và hiệu ứng xoay */
        .nut-7-mau {
            animation: nhayMauNen 1.5s infinite !important;
            transition: transform 0.6s ease-in-out; /* Thời gian xoay 0.6s */
        }

        /* Khi di chuột vào nút sẽ xoay 360 độ */
        .nut-7-mau:hover {
            transform: rotate(360deg);
        }

        /* Trạng thái ban đầu của link quay lại */
        .link-chay {
            display: inline-block;
            transition: transform 0.4s ease-out; /* Tốc độ trượt sang phải */
        }

        /* Class được kích hoạt khi chạm chuột để cố định vị trí mới */
        .da-chay-sang-phai {
            transform: translateX(120px); /* Khoảng cách trượt sang phải (120px) */
        }
    </style>
</head>
<body class="bg-body-tertiary d-flex align-items-center min-vh-100 overflow-hidden">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-11 col-sm-8 col-md-6 col-lg-4">
                
                <div class="card border-0 shadow-lg rounded-4">
                    <div class="card-body p-4 p-sm-5">
                        <h2 class="text-center mb-4 fw-bold chu-7-mau">Đăng Nhập</h2>

                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger rounded-3">
                            <?php echo e($errors->first()); ?>

                        </div>
                        <?php endif; ?>

                        <form action="<?php echo e(route('login')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="email" class="form-label fw-bold chu-7-mau">Email</label>
                                <input type="email" name="email" class="form-control form-control-lg bg-light" id="email" required>
                            </div>
                            
                            <div class="mb-4">
                                <label for="password" class="form-label fw-bold chu-7-mau">Mật khẩu</label>
                                <input type="password" name="password" class="form-control form-control-lg bg-light" id="password" required>
                            </div>
                            
                            <div class="d-grid mb-3">
                                <button type="submit" class="btn btn-lg fw-bold rounded-3 nut-7-mau chu-7-mau">Đăng nhập</button>
                            </div>
                            
                            <div class="text-center mt-4">
                                <p class="text-muted mb-2">
                                    Chưa có tài khoản? <a href="<?php echo e(route('register')); ?>" class="text-primary text-decoration-none fw-bold">Đăng ký ngay</a>
                                </p>
                                <a href="<?php echo e(route('client.product.index')); ?>" 
                                   class="text-decoration-none text-secondary fw-bold link-chay mt-2"
                                   onmouseenter="this.classList.add('da-chay-sang-phai')">
                                    &larr; Quay lại Trang chủ
                                </a>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\hung_asm\resources\views/auth/login.blade.php ENDPATH**/ ?>
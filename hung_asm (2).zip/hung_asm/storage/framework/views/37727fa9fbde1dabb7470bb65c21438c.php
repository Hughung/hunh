<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <style>
        /* 1. Nền 7 màu rực rỡ */
        @keyframes nhayMauNen {
            0% { background-color: red; border-color: red; } 
            14% { background-color: orange; border-color: orange; } 
            28% { background-color: yellow; border-color: yellow; }
            42% { background-color: green; border-color: green; } 
            57% { background-color: blue; border-color: blue; } 
            71% { background-color: indigo; border-color: indigo; }
            85% { background-color: violet; border-color: violet; } 
            100% { background-color: red; border-color: red; }
        }
        .nen-7-mau {
            animation: nhayMauNen 1.5s infinite !important;
            color: white !important;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.5);
        }

        /* 2. Hiệu ứng quẩy lắc lư khi di chuột */
        @keyframes lacLu {
            0% { transform: rotate(0deg); }
            25% { transform: rotate(-15deg) scale(1.1); }
            50% { transform: rotate(15deg) scale(1.1); }
            75% { transform: rotate(-15deg) scale(1.1); }
            100% { transform: rotate(0deg) scale(1); }
        }
        .nut-lac-lu:hover {
            animation: lacLu 0.3s infinite;
            z-index: 10;
        }

        /* 3. Hiệu ứng nhịp đập báo động cho nút Đăng xuất */
        @keyframes canhBao {
            0% { transform: scale(1); box-shadow: 0 0 5px red; }
            50% { transform: scale(1.1); box-shadow: 0 0 20px red, 0 0 10px yellow; }
            100% { transform: scale(1); box-shadow: 0 0 5px red; }
        }
        .nut-dang-xuat {
            animation: canhBao 0.6s infinite;
            transition: transform 0.3s ease-in-out;
        }

        /* 4. Đăng xuất lộn ngược khi cố chạm vào */
        .nut-dang-xuat:hover {
            transform: translateY(-15px) rotate(180deg) scale(1.2) !important;
            animation: none; /* Dừng nháy để xoay cho chóng mặt */
        }
    </style>
</head>
<body class="bg-light">
    <div class="container mt-4">
        
        <div class="d-flex justify-content-between align-items-center mb-4 p-3 bg-white border border-2 border-primary rounded-4 shadow">
            
            <div class="d-flex gap-2">
                <a href="<?php echo e(route('categories.index')); ?>" class="btn fw-bold nen-7-mau nut-lac-lu">Quản lí danh mục</a>
                <a href="<?php echo e(route('products.index')); ?>" class="btn fw-bold nen-7-mau nut-lac-lu">Quản lí sản phẩm</a>
            </div>

            <form action="<?php echo e(route('logout')); ?>" method="POST" class="m-0">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-danger fw-bold nut-dang-xuat">Đăng xuất</button>
            </form>

        </div>

        <div class="content-area bg-white p-4 rounded-4 shadow-sm">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        
    </div>
</body>
</html><?php /**PATH C:\Users\PC\Downloads\htdocs\ASM---PHP3\hehehe\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>
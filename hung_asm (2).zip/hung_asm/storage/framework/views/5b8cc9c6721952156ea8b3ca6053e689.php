

<?php $__env->startSection('title', "Sửa sản phẩm"); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h2>Sửa sản phẩm</h2>
    </div>
    <div class="card-body">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('products.update', $product->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="mb-3">
                <label class="form-label">Tên sản phẩm</label>
                <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $product->name)); ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Giá</label>
                <input type="number" name="price" class="form-control" value="<?php echo e(old('price', $product->price)); ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Số lượng</label>
                <input type="number" name="quantity" class="form-control" value="<?php echo e(old('quantity', $product->quantity)); ?>">
            </div>
            
            <div class="mb-3">
                <label class="form-label">Danh mục</label>
                <select name="category_id" class="form-control">
                        <option value="">
                        </option>
                </select>
            </div>
            
            <div class="mb-3">
                <label class="form-label">Ảnh hiện tại</label><br>
                <?php if($product->image): ?>
                    <img src="<?php echo e(asset('storage/' . $product->image)); ?>" width="150" alt="Ảnh SP" class="img-thumbnail">
                <?php else: ?>
                    <span class="text-danger">Chưa có ảnh</span>
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <label class="form-label">Đổi ảnh mới (Bỏ trống nếu giữ nguyên ảnh cũ)</label>
                <input type="file" name="image" class="form-control">
            </div>
            
            <div class="mb-3">
                <label class="form-label">Trạng thái</label>
                <select name="status" class="form-control">
                    <option value="1" <?php echo e($product->status == 1 ? 'selected' : ''); ?>>Hoạt động</option>
                    <option value="0" <?php echo e($product->status == 0 ? 'selected' : ''); ?>>Tạm dừng</option>
                </select>
            </div>
            <button type="submit" class="btn btn-success">Lưu thay đổi</button>
            <a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary">Quay lại</a>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\ASM---PHP3\quan\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>
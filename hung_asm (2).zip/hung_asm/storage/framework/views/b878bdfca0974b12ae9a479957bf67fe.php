<?php if(session('success')): ?>
<div class="alert alert-success">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(session('error')): ?>
<div class="alert alert-danger">
    <?php echo e(session('error')); ?>

</div>
<?php endif; ?>

<?php $__env->startSection('title', "Sửa danh mục"); ?>;

<?php $__env->startSection('content'); ?>
<div class="card">
    <h2>Sửa danh mục</h2>
    <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary">Sửa danh mục</a>
    <div class="card-body">
        <form action="<?php echo e(route('categories.update', $category->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="mb-3">
                <label class="form-label">Tên</label>
                <input type="text" name="name" class="form-control" value="<?php echo e($category->name); ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Trạng thái</label>
                <select name="status">
                    <option value="1" <?php echo e($category->status == 1 ? 'selected' : ''); ?>>Hoạt động</option>
                    <option value="0" <?php echo e($category->status == 0 ? 'selected' : ''); ?>>Tạm dừng</option>
                </select>
            </div>
            <button type="submit" class="btn btn-success">Lưu</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\ASM---PHP3\quan\resources\views/admin/categories/edit.blade.php ENDPATH**/ ?>
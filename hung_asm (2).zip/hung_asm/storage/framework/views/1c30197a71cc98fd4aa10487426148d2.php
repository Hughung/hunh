<?php if(session('success')): ?>
<div class="alert alert-success">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(session('error')): ?>
<div class="alert alert-danger">
    <?php echo e(session('error')); ?>

</div>
<?php endif; ?>

<?php $__env->startSection('title', "Danh mục sản phẩm"); ?>;

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Danh mục sản phẩm</h2>
    <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary">Thêm danh mục</a><br><br>
    <form action="<?php echo e(route('categories.index')); ?>" method="GET" class="mb-3">
        <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Tìm kiếm danh mục..." value="<?php echo e(request('search')); ?>">
            <button type="submit" class="btn btn-outline-secondary">Tìm kiếm</button>
        </div>
    </form>
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Tên</th>
                <th>Moo tả</th>
                <th>Hành Động</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($category -> id); ?></td>
                <td><?php echo e($category -> name); ?></td>
                <td><?php echo e($category -> description); ?></td>
                <td>
                    <a href="<?php echo e(route('categories.edit', $category->id)); ?>" class="btn btn-warning">Sửa</a>
                    <form action="<?php echo e(route('categories.destroy', $category->id)); ?>" class="d-inline" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("DELETE"); ?>
                        <button type="submit" class="btn btn-danger" onclick="return confirm('Fen cúa chắc mún xóa hông?')">Xóa<s/button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($categories -> links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PC\Downloads\htdocs\ASM---PHP3\hehehe\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title', "Quản lý sản phẩm"); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Quản lý sản phẩm</h2>
    <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary mb-3">Thêm sản phẩm</a>
    
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <form action="<?php echo e(route('products.index')); ?>" method="GET" class="mb-3">
        <div class="input-group">
            <input type="text" name="search" class="form-control" placeholder="Tìm sản phẩm..." value="<?php echo e(request('search')); ?>">
            <button type="submit" class="btn btn-outline-secondary">Tìm kiếm</button>
        </div>
    </form>

    <table class="table table-bordered text-center align-middle">
        <thead>
            <tr>
                <th>ID</th>
                <th>Ảnh</th>
                <th>Tên SP</th>
                <th>Giá</th>
                <th>Số lượng</th>
                <th>Danh mục</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($pro->id); ?></td>
                <td>
                    <?php if($pro->image): ?>
                        <img src="<?php echo e(asset('storage/' . $pro->image)); ?>" width="80" alt="<?php echo e($pro->name); ?>">
                    <?php else: ?>
                        <span>Chưa có ảnh</span>
                    <?php endif; ?>
                </td>
                <td><?php echo e($pro->name); ?></td>
                <td><?php echo e(number_format($pro->price)); ?> đ</td>
                <td><?php echo e($pro->quantity); ?></td>
                <td><?php echo e($pro->category->name); ?></td>
                <td>
                    <a href="<?php echo e(route('products.edit', $pro->id)); ?>" class="btn btn-warning btn-sm">Sửa</a>
                    <form action="<?php echo e(route('products.destroy', $pro->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?> <?php echo method_field("DELETE"); ?>
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Bạn có chắc muốn xóa?')">Xóa</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($products->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PC\Downloads\htdocs\ASM---PHP3\hehehe\resources\views/admin/products/index.blade.php ENDPATH**/ ?>
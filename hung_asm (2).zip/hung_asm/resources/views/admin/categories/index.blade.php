@extends('admin.layouts.app')
@section('title', "Quản Lý Danh Mục")

@section('content')
<style>
    .search-box { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 1.5rem; border-radius: 12px; margin-bottom: 2rem; }
    .btn-add { background: linear-gradient(135deg, #00d084 0%, #00a86b 100%); border: none; color: white; border-radius: 8px; }
</style>

@if(session('success'))
    <div class="alert alert-success">✅ {{ session('success') }}</div>
@endif

@if(session('error'))
    <div class="alert alert-danger">❌ {{ session('error') }}</div>
@endif

<div class="d-flex justify-content-between align-items-center mb-3">
    <h2 style="color: #667eea; font-weight: 700;">📂 Quản Lý Danh Mục</h2>
    <a href="{{ route('categories.create') }}" class="btn btn-add">+ Thêm Danh Mục</a>
</div>

<div class="search-box">
    <form action="{{ route('categories.index') }}" method="GET" class="d-flex gap-2">
        <input type="text" name="search" class="form-control" placeholder="🔍 Tìm danh mục..." value="{{ request('search') }}">
        <button type="submit" class="btn btn-light fw-bold">Tìm Kiếm</button>
    </form>
</div>

<div class="table-responsive">
    <table class="table table-hover align-middle">
        <thead>
            <tr>
                <th style="color: white;">ID</th>
                <th style="color: white;">Tên</th>
                <th style="color: white;">Mô tả</th>
                <th style="color: white;">Hành Động</th>
            </tr>
        </thead>
        <tbody>
            @forelse($categories as $category)
            <tr>
                <td><strong>#{{ $category->id }}</strong></td>
                <td><strong>{{ $category->name }}</strong></td>
                <td>{{ Str::limit($category->description, 50) }}</td>
                <td>
                    <a href="{{ route('categories.edit', $category->id) }}" class="btn btn-warning btn-sm">✏️ Sửa</a>
                    <form action="{{ route('categories.destroy', $category->id) }}" class="d-inline" method="POST">
                        @csrf @method("DELETE")
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Bạn chắc chắn muốn xóa?')">🗑️ Xóa</button>
                    </form>
                </td>
            </tr>
            @empty
            <tr><td colspan="4" class="text-center text-muted py-4">Không có danh mục nào</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection
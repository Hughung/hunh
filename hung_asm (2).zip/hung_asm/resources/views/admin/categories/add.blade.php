@extends('admin.layouts.app')
@section('title', "Thêm Danh Mục")

@section('content')
<style>
    .form-label { font-weight: 700; color: #667eea; }
    .form-control { border-radius: 8px; border: 2px solid #e0e0e0; }
    .form-control:focus { border-color: #667eea; box-shadow: 0 0 12px rgba(102, 126, 234, 0.3); }
    .btn-submit { background: linear-gradient(135deg, #00d084 0%, #00a86b 100%); border: none; color: white; font-weight: 700; border-radius: 8px; }
</style>

@if(session('success'))
    <div class="alert alert-success">✅ {{ session('success') }}</div>
@endif

@if(session('error'))
    <div class="alert alert-danger">❌ {{ session('error') }}</div>
@endif

<h2 style="color: #667eea; font-weight: 700; margin-bottom: 2rem;">➕ Thêm Danh Mục Mới</h2>

<div class="row">
    <div class="col-md-8">
        <form action="{{ route('categories.store') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="mb-3">
                <label class="form-label">📝 Tên Danh Mục</label>
                <input type="text" name="name" class="form-control" placeholder="Nhập tên danh mục">
            </div>
            <div class="mb-3">
                <label class="form-label">📄 Mô Tả</label>
                <textarea name="description" class="form-control" rows="4" placeholder="Nhập mô tả danh mục"></textarea>
            </div>
            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-submit">💾 Thêm Mới</button>
                <a href="{{ route('categories.index') }}" class="btn btn-secondary">↩️ Quay Lại</a>
            </div>
        </form>
    </div>
</div>
@endsection
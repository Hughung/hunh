@extends('admin.layouts.app')
@section('title', "Thêm Sản Phẩm")

@section('content')
<style>
    .form-label { font-weight: 700; color: #667eea; }
    .form-control, .form-select { border-radius: 8px; border: 2px solid #e0e0e0; }
    .form-control:focus, .form-select:focus { border-color: #667eea; box-shadow: 0 0 12px rgba(102, 126, 234, 0.3); }
    .btn-submit { background: linear-gradient(135deg, #00d084 0%, #00a86b 100%); border: none; color: white; font-weight: 700; border-radius: 8px; }
</style>

<h2 style="color: #667eea; font-weight: 700; margin-bottom: 2rem;">➕ Thêm Sản Phẩm Mới</h2>

@if ($errors->any())
    <div class="alert alert-danger"><ul class="mb-0">@foreach ($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>
@endif

<div class="row">
    <div class="col-md-8">
        <form action="{{ route('products.store') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="mb-3">
                <label class="form-label">📝 Tên Sản Phẩm</label>
                <input type="text" name="name" class="form-control" placeholder="Nhập tên sản phẩm" value="{{ old('name') }}">
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label class="form-label">💵 Giá</label>
                        <input type="number" name="price" class="form-control" placeholder="0" value="{{ old('price') }}">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label class="form-label">📦 Số Lượng</label>
                        <input type="number" name="quantity" class="form-control" placeholder="0" value="{{ old('quantity') }}">
                    </div>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">📂 Danh Mục</label>
                <select name="category_id" class="form-select">
                    <option value="">-- Chọn danh mục --</option>
                    @foreach($categories as $cate)<option value="{{ $cate->id }}" {{ old('category_id') == $cate->id ? 'selected' : '' }}>{{ $cate->name }}</option>@endforeach
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">🖼️ Ảnh Sản Phẩm</label>
                <input type="file" name="image" class="form-control">
            </div>
            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-submit">💾 Thêm Mới</button>
                <a href="{{ route('products.index') }}" class="btn btn-secondary">↩️ Quay Lại</a>
            </div>
        </form>
    </div>
</div>
@endsection
@extends('admin.layouts.app')
@section('title', "Quản lý sản phẩm")
@section('content')
<style>
    .search-box { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 1.5rem; border-radius: 12px; margin-bottom: 2rem; }
    .search-box input { border-radius: 8px; border: 2px solid #e0e0e0; }
    .btn-add { background: linear-gradient(135deg, #00d084 0%, #00a86b 100%); border: none; color: white; border-radius: 8px; }
</style>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h2 style="color: #667eea; font-weight: 700;">📦 Quản Lý Sản Phẩm</h2>
    <a href="{{ route('products.create') }}" class="btn btn-add">+ Thêm Sản Phẩm</a>
</div>

@if(session('success'))
    <div class="alert alert-success">✅ {{ session('success') }}</div>
@endif

<div class="search-box">
    <form action="{{ route('products.index') }}" method="GET" class="d-flex gap-2">
        <input type="text" name="search" class="form-control" placeholder="🔍 Tìm sản phẩm..." value="{{ request('search') }}">
        <button type="submit" class="btn btn-light fw-bold">Tìm Kiếm</button>
    </form>
</div>

<div class="table-responsive">
    <table class="table table-hover align-middle">
        <thead>
            <tr>
                <th style="color: white;">ID</th>
                <th style="color: white;">Ảnh</th>
                <th style="color: white;">Tên SP</th>
                <th style="color: white;">Giá</th>
                <th style="color: white;">Số lượng</th>
                <th style="color: white;">Danh mục</th>
                <th style="color: white;">Hành động</th>
            </tr>
        </thead>
        <tbody>
            @forelse($products as $pro)
            <tr>
                <td><strong>#{{ $pro->id }}</strong></td>
                <td>@if($pro->image)<img src="{{ asset('storage/' . $pro->image) }}" width="70" height="70" style="border-radius: 10px;" alt="{{ $pro->name }}">@else<span class="text-muted">-</span>@endif</td>
                <td><strong>{{ $pro->name }}</strong></td>
                <td class="text-danger fw-bold">{{ number_format($pro->price) }}đ</td>
                <td><span class="badge bg-info">{{ $pro->quantity }}</span></td>
                <td>{{ $pro->category->name ?? 'N/A' }}</td>
                <td>
                    <a href="{{ route('products.edit', $pro->id) }}" class="btn btn-warning btn-sm">✏️ Sửa</a>
                    <form action="{{ route('products.destroy', $pro->id) }}" method="POST" class="d-inline">
                        @csrf @method("DELETE")
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Bạn chắc chắn muốn xóa?')">🗑️ Xóa</button>
                    </form>
                </td>
            </tr>
            @empty
            <tr><td colspan="7" class="text-center text-muted py-4">Không có sản phẩm nào</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection
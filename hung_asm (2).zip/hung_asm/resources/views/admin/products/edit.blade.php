@extends('admin.layouts.app')
@section('title', "Sửa Sản Phẩm")

@section('content')
<style>
    .form-label { font-weight: 700; color: #667eea; }
    .form-control, .form-select { border-radius: 8px; border: 2px solid #e0e0e0; }
    .form-control:focus, .form-select:focus { border-color: #667eea; box-shadow: 0 0 12px rgba(102, 126, 234, 0.3); }
    .btn-submit { background: linear-gradient(135deg, #00d084 0%, #00a86b 100%); border: none; color: white; font-weight: 700; border-radius: 8px; }
    .img-preview { border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
</style>

<h2 style="color: #667eea; font-weight: 700; margin-bottom: 2rem;">✏️ Sửa Sản Phẩm</h2>

@if ($errors->any())
    <div class="alert alert-danger"><ul class="mb-0">@foreach ($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>
@endif

<div class="row">
    <div class="col-md-8">
        <form action="{{ route('products.update', $product->id) }}" method="POST" enctype="multipart/form-data">
            @csrf @method('PUT')
            <div class="mb-3">
                <label class="form-label">📝 Tên Sản Phẩm</label>
                <input type="text" name="name" class="form-control" value="{{ old('name', $product->name) }}">
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label class="form-label">💵 Giá</label>
                        <input type="number" name="price" class="form-control" value="{{ old('price', intval($product->price)) }}">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label class="form-label">📦 Số Lượng</label>
                        <input type="number" name="quantity" class="form-control" value="{{ old('quantity', $product->quantity) }}">
                    </div>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">📂 Danh Mục</label>
                <select name="category_id" class="form-select">
                    <option value="">-- Chọn danh mục --</option>
                    @foreach($categories as $cate)<option value="{{ $cate->id }}" {{ (old('category_id') ?? $product->category_id) == $cate->id ? 'selected' : '' }}>{{ $cate->name }}</option>@endforeach
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">🖼️ Ảnh Hiện Tại</label>
                @if($product->image)
                    <br><img src="{{ asset('storage/' . $product->image) }}" width="150" class="img-preview mt-2" alt="Ảnh SP">
                @else
                    <p class="text-danger">Chưa có ảnh</p>
                @endif
            </div>
            <div class="mb-3">
                <label class="form-label">🖼️ Đổi Ảnh Mới (Bỏ trống nếu giữ ảnh cũ)</label>
                <input type="file" name="image" class="form-control">
            </div>
            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-submit">💾 Lưu Thay Đổi</button>
                <a href="{{ route('products.index') }}" class="btn btn-secondary">↩️ Quay Lại</a>
            </div>
        </form>
    </div>
</div>
@endsection
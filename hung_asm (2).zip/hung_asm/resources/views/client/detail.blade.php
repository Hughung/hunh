<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chi Tiết - {{ $product->name }}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 1.5rem 0;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            margin-bottom: 2rem;
        }

        .header-title {
            color: white;
            font-weight: 700;
            font-size: 1.5rem;
        }

        .detail-container {
            background: white;
            border-radius: 18px;
            padding: 2.5rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.08);
            margin-bottom: 2rem;
        }

        .product-image {
            border-radius: 15px;
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.2);
            overflow: hidden;
            max-height: 450px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        }

        .product-image img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
        }

        .product-info {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
        }

        .product-name {
            font-size: 2rem;
            font-weight: 700;
            color: #333;
        }

        .product-category {
            display: inline-block;
            background: #667eea;
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-weight: 600;
            width: fit-content;
        }

        .product-price {
            font-size: 2.2rem;
            font-weight: 700;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .info-row {
            display: flex;
            align-items: center;
            padding: 1rem;
            background: #f8f9ff;
            border-radius: 12px;
            gap: 1rem;
        }

        .info-row strong {
            color: #667eea;
            min-width: 120px;
        }

        .description {
            background: #f8f9ff;
            padding: 1.5rem;
            border-radius: 12px;
            border-left: 4px solid #667eea;
            line-height: 1.8;
            color: #555;
        }

        .btn-back {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 12px;
            padding: 0.9rem 2rem;
            font-weight: 700;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }

        .btn-back:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(102, 126, 234, 0.3);
            color: white;
        }

        .placeholder-image {
            font-size: 4rem;
            color: #ccc;
        }
    </style>
</head>
<body>

    <div class="header">
        <div class="container">
            <h1 class="header-title">🛍️ Chi Tiết Sản Phẩm</h1>
        </div>
    </div>

    <div class="container">
        <div class="detail-container">
            <div class="row g-4">
                <!-- Product Image -->
                <div class="col-lg-5">
                    <div class="product-image">
                        @if($product->image)
                            <img src="{{ asset('storage/' . $product->image) }}" alt="{{ $product->name }}">
                        @else
                            <span class="placeholder-image">📷</span>
                        @endif
                    </div>
                </div>

                <!-- Product Info -->
                <div class="col-lg-7">
                    <div class="product-info">
                        <h2 class="product-name">{{ $product->name }}</h2>

                        <div>
                            <span class="product-category">
                                📂 {{ $product->category->name ?? 'Không xác định' }}
                            </span>
                        </div>

                        <div class="product-price">
                            💰 {{ number_format($product->price) }}đ
                        </div>

                        <div class="info-row">
                            <strong>📦 Số lượng:</strong>
                            <span>{{ $product->quantity }} sản phẩm có sẵn</span>
                        </div>

                        <hr style="margin: 1rem 0; border-color: #ddd;">

                        <h5 style="color: #667eea; font-weight: 700; margin-bottom: 1rem;">📝 Mô Tả Sản Phẩm</h5>
                        <div class="description">
                            {{ $product->description }}
                        </div>

                        <div style="margin-top: 1.5rem;">
                            <a href="{{ route('client.product.index') }}" class="btn-back">⬅️ Quay Lại Danh Sách</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
</html>